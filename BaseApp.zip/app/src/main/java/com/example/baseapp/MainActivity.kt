package com.example.baseapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    lateinit var button1 : Button //변수 선언
    lateinit var button2 : Button
    lateinit var id : EditText
    lateinit var password : EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main);

        val intent = Intent(applicationContext, SplashActivity::class.java)
        startActivity(intent)

        title = "로그인 화면"

        button1 = findViewById(R.id.Button1)
        button2 = findViewById(R.id.Button2)

        id = findViewById(R.id.Edit1)
        password = findViewById(R.id.Edit2)

    }

}