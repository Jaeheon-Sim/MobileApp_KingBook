package com.moapp.kingbook

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {
    lateinit var button1 : Button //변수 선언
    lateinit var button2 : Button
    lateinit var id : EditText
    lateinit var password : EditText
    var waitTime = 0L
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login);

        val intent = Intent(applicationContext, SplashActivity::class.java)
        startActivity(intent)

        title = "로그인 화면"

        button1 = findViewById(R.id.Button1)
        button2 = findViewById(R.id.Button2)

        id = findViewById(R.id.Edit1)
        password = findViewById(R.id.Edit2)

        Button1.setOnClickListener {
            val intent = Intent(this, TabActivity::class.java)
            startActivity(intent)
        }

    }
    override fun onBackPressed(){

        if(System.currentTimeMillis() - waitTime >= 1500){
            waitTime = System.currentTimeMillis()
            Toast.makeText(this,"뒤로가기 버튼을 한번 더 누르면 종료됩니다",Toast.LENGTH_SHORT).show()
        }else{
            finish()
        }
    }

}